#!/bin/sh
export LD_LIBRARY_PATH=.
export LITE_HOME=`dirname $0`
export LITE_URI="file://./ishapes-us.xml"
if [ -z $1 ]; then
  echo -n "Enter your email address (the same used to log on the vortex demo): "; read PARTITION
else
  PARTITION=$1
fi
./ishapes $PARTITION
