#!/bin/sh
export LD_LIBRARY_PATH=.
export LITE_HOME=`dirname $0`
export LITE_URI="file://./ishapes.xml"
./ishapes
