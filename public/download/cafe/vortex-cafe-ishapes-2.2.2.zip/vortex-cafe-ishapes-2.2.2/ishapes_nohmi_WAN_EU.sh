#!/bin/sh
#
#                             Vortex Cafe
#
#    This software and documentation are Copyright 2010 to 2016 PrismTech
#    Limited and its licensees. All rights reserved. See file:
#
#                           docs/LICENSE.html
#
#    for full copyright notice and license terms.
#

ADDR=88.80.185.102

BASE_PORT=10000
PORT_OFFSET=${RANDOM}%1000
LOCAL_PORT=$((BASE_PORT+PORT_OFFSET))

PARTITION=$1
VERSION=2.2.2
JAR_PATH=target
PUBLIC_DISCOVERY_PORT=7400
DISCOVERY_LOCATOR=${ADDR}:${PUBLIC_DISCOVERY_PORT}

if [ $# -lt 1 ]; then
    echo -n "Enter your email address (the same used to log on the vortex demo): "
    read PARTITION
fi


java \
    -Dddsi.network.transport=tcp \
    -Dddsi.discovery.tcp.peers=${DISCOVERY_LOCATOR} \
    -Dddsi.discovery.externalNetworkAddresses=none \
    -Dddsi.discovery.tcp.port=${LOCAL_PORT} \
    -Ddds.partition=${PARTITION} \
    -DrefreshTimeout=40 \
    -jar ${JAR_PATH}/ishapes-${VERSION}.jar --noHMI --script demo.js

