#!/bin/sh
#
#                             Vortex Cafe
#
#    This software and documentation are Copyright 2010 to 2016 PrismTech
#    Limited and its licensees. All rights reserved. See file:
#
#                           docs/LICENSE.html
#
#    for full copyright notice and license terms.
#

PARTITION=$1
VERSION=2.2.2
JAR_PATH=target


java \
    -Ddds.partition=${PARTITION} \
    -DrefreshTimeout=40 \
    -jar ${JAR_PATH}/ishapes-${VERSION}.jar &>/dev/null 
