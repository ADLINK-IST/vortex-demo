/*
 *                             Vortex Cafe
 *
 *    This software and documentation are Copyright 2010 to 2017 PrismTech
 *    Limited and its licensees. All rights reserved. See file:
 *
 *                           docs/LICENSE.html
 *
 *    for full copyright notice and license terms.
 */
//
// Here is an example of script to add shapes publications/subscriptions.
//
// Available variables are:
//   - controller    : the controller to add publications/subscriptions
//   - policyFactory : the QoS PolicyFactory
//   - CIRCLE, SQUARE, TRIANGLE : the shape kinds to be used
//
// To add a publication of a blue circle with default size, speed and QoS:
//    controller.addPublication(CIRCLE, "BLUE");
//
// To add a publication of a RED circle with default QoS, size=20 and speed=8 :
//    controller.addPublication(CIRCLE, "BLUE", 20, 8);
//
// To add a publication of a GREEN circle with specific QoS:
//    controller.addPublication(CIRCLE, "BLUE",
//        policyFactory.Reliability().withReliable(),
//        policyFactory.Ownership().withExclusive(),
//        policyFactory.OwnershipStrength().withValue(10));
//
// To add a subscription to circles with default QoS:
//    controller.addSubscription(CIRCLE);
//
// To add a subscription to circles with specific QoS:
//    controller.addSubscription(CIRCLE,
//        policyFactory.Reliability().withReliable(),
//        policyFactory.History().withKeepLast(3));
//


controller.addPublication(CIRCLE, "BLUE",
    policyFactory.Reliability().withBestEffort());
controller.addPublication(CIRCLE, "RED",
    policyFactory.Reliability().withBestEffort());
controller.addPublication(CIRCLE, "YELLOW",
    policyFactory.Reliability().withBestEffort());


controller.addSubscription(SQUARE,
    policyFactory.History().withKeepLast(3));

