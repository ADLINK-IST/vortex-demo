/*
 *                             Vortex Cafe
 *
 *    This software and documentation are Copyright 2010 to 2015 PrismTech
 *    Limited and its licensees. All rights reserved. See file:
 *
 *                           docs/LICENSE.html
 *
 *    for full copyright notice and license terms.
 */

controller.addPublication(CIRCLE, "BLUE",
			  policyFactory.Reliability().withBestEffort());


controller.addSubscription(SQUARE,
			   policyFactory.Reliability().withBestEffort());
