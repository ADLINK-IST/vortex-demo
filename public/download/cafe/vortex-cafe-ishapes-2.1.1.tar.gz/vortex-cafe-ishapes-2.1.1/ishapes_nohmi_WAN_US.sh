#!/bin/sh
#
#                             Vortex Cafe
#
#    This software and documentation are Copyright 2010 to 2015 PrismTech
#    Limited and its licensees. All rights reserved. See file:
#
#                           docs/LICENSE.html
#
#    for full copyright notice and license terms.
#

ADDR=66.175.212.58

BASE_PORT=10000
PORT_OFFSET=${RANDOM}%1000
LOCAL_PORT=$((BASE_PORT+PORT_OFFSET))

PARTITION=$1
VERSION=2.1.1
JAR_PATH=.
PUBLIC_DISCOVERY_PORT=7400
DISCOVERY_LOCATOR=${ADDR}:${PUBLIC_DISCOVERY_PORT}

if [ $# -lt 1 ]; then
    echo -n "Enter your email address (the same used to log on the vortex demo): "
    read PARTITION
fi

#     -Ddds.registerType=org.omg.dds.demo.ShapeType \

java \
    -Dddsi.network.transport=tcp \
    -Dddsi.discovery.tcp.peers=${DISCOVERY_LOCATOR} \
    -Dddsi.discovery.externalNetworkAddresses=none \
    -Dddsi.discovery.tcp.port=${LOCAL_PORT} \
    -Ddds.partition=${PARTITION} \
    -DrefreshTimeout=40 \
    -jar ${JAR_PATH}/ishapes-${VERSION}.jar --noHMI --script demo.js

